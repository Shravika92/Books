package com.book.exception;

public class BookException extends Exception {
	public BookException()
	{
		super();
	}
	public BookException(String msg)
	{
		super(msg);
	}
	

}
